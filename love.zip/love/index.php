<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Pyari Milli</title>
		<style media="screen">
			body, html{padding:0;margin:0;}
			body,a{background:#CE0011;color:#fff;text-decoration:none;
font-family: verdana;
			}
			.head{
				padding:10%;text-align:center;
			}
			a{border:5px solid #fff;}
			.asd{    background: #CE0011;-webkit-appearance: none;

    color: #fff;
    border: 2px solid #fff;
    padding: 10px;}
		</style><meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script>
function say()
{
	alert('By the moon as I sit to seek yor glory,\nthe red roses i see,\ncreates a new story.\nSeasons are many,\ntheir reasons are few.\nWhat remains is that\n\nI will always love you my mishri.\n\n\n');
	alert('Oh, stop thinking now,\nI know this proposal was a BAD idea.\nI will come up with something better next time.\nI promise.\n\n\n');
	return false;
}
		</script>
	</head>
	<body>
		<div class="head">
			<img src="a.jpg" alt="" style="
    width: 100%;
">
			<p>You are so wonderful Milli,<br /> I'm so lucky that you are mine.<br /> And I'll be smilling all day long.<br /> If you will be my Valentine </p>
			<p> <strong>So, Will you me My Valentine ?</strong></p>
			<form action="" onsubmit="return say();">
			<label><input type="radio"  name="asds" required="required" />A). Yes </label><br /><br />
			<label><input type="radio" name="asds"   />B). (A) </label><br /><br />
			<label><input type="radio" name="asds"   />C). (B) </label><br /><br />
			<input type="submit"class="asd" value="SUBMIT ASNWER">
			</form>



		</div>

	</body>
</html>
